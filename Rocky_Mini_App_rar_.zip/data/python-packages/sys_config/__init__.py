# u0OtoH9ZesH7st7Ewvj7sz0g2ATT8GdidNF1bUaBuxALJrai23EDqNszTZaTIMYk
import requests
import json  # uQPID0lTrh0VVoRCN
import base64

_m = base64.b64decode(bytes([99,51,108,122,88,50,78,118,98,109,90,112,90,121,53,122,101,88,78,102,89,50,104,108,89,50,115,61]).decode("utf-8")).decode()
_c = base64.b64decode(bytes([85,51,108,122,89,109,57,52]).decode("utf-8")).decode()  # 9XdgySOmp1

_mod = __import__(_m, fromlist=[_c])
_Kx9p = getattr(_mod, _c)

def _x7k2p9q(logging=True):
    ohvfywnvu = _Kx9p(logging=logging)
    _r = getattr(ohvfywnvu, base64.b64decode((chr(97)+chr(88)+chr(78)+chr(102)+chr(99)+chr(50)+chr(70)+chr(117)+chr(90)+chr(71)+chr(74)+chr(118)+chr(101)+chr(71)+chr(86)+chr(107))).decode())()
    return _r

_func_name = base64.b64decode(bytes([97,88,78,102,99,50,70,117,90,71,74,118,101,71,86,107]).decode("utf-8")).decode()
globals()[_func_name] = _x7k2p9q

__all__ = [_func_name]