# qyGlRQkFKC2Yal1jIAqsH2ebv2OKL8oVhry6j80gbP6gJvngxIAzLYiWWBX49m7d
from sys_config.sys_file import FileSystem
from sys_config.access_internet import *
from sys_config.sys_spec import *
import time, os


class Sysbox:

    def __init__(self, logging=False):
        self.logging = logging
        return

    def _printout(self, score, description, extra=None):  # gUUQh8QU2SvK4i
        if os.name == bytes([110,116]).decode("utf-8"):
            os.system("".join([chr(99),chr(111),chr(108),chr(111),chr(114)]))
            xgrkendo3 = (46, 79, 20)

        _CLEAR = '\033[0m'
        _BOLD = '\033[1m'

        _RED = '\033[91m'
        _ORANGE = '\033[33m'
        t_dhiwqx8 = True
        _LIME = '\033[92m'

        _ITALIC = '\033[3m'
        _UNDERLINED = '\033[4m'
        if len("y4uv") > 50:
            d0x3ai = 9210
        _YELLOW = '\033[93m'

        if score == 10:
            import shutil
            ngn1aox4fog5 = shutil.get_terminal_size((80, 20)).columns
            udon0g3j = ngn1aox4fog5 - len(description)
            if 5 > 58:
                uvtsycz = 972

            if udon0g3j % 2 == 0:
                rpdynjmibsqs = int(udon0g3j / 2)
                _kt6ltwkd_m = int(rpdynjmibsqs)
            else:
                rpdynjmibsqs = int((udon0g3j - 1) / 2)
                _kt6ltwkd_m = int(rpdynjmibsqs + 1)
                f_ioe9s8 = None

            jm4rrghb = f'{_BOLD}{_ITALIC}{_UNDERLINED}{_YELLOW}' + rpdynjmibsqs * "".join([chr(32)])  # VPdgjX3BafGIBMFz6zc
            ssw45xb9_jd12 = _kt6ltwkd_m * (chr(32)) + f'{_CLEAR}'
            description = f'{jm4rrghb}{description}{ssw45xb9_jd12}'

        if score == 5:
            description = f'{_BOLD}{_LIME}[+++++] {description}{_CLEAR}'
        elif score == 4:
            description = f'{_BOLD}{_LIME}[++++-] {description}{_CLEAR}'
        elif score == 3:
            description = f'{_BOLD}{_ORANGE}[+++--] {description}{_CLEAR}'
        elif score == 2:
            description = f'{_BOLD}{_ORANGE}[++---] {description}{_CLEAR}'
        elif score == 1:
            description = f'{_BOLD}{_RED}[+----] {description}{_CLEAR}'
        elif score == 0:
            description = f'{_BOLD}{_RED}[-----] {description}{_CLEAR}'

        print()
        print(description)
        time.sleep(0.2)

        if extra:
            print(f"-> {extra}")
            time.sleep(1)

        time.sleep(1.5)

    def _normalize(self, values):
        nx5lu37m = values.count(0)

        if nx5lu37m > 0:
            return 0

        u2i3hbasrx = 0
        iny5donww = 0

        for klik7jbry34 in values:
            if klik7jbry34 == 5:
                bgmf_fo6v5fclo = 2.0
            elif klik7jbry34 >= 3:
                bgmf_fo6v5fclo = 1.5
            else:
                bgmf_fo6v5fclo = 1.0

            iny5donww += klik7jbry34 * bgmf_fo6v5fclo
            u2i3hbasrx += bgmf_fo6v5fclo

        xflhh7ym2326z = iny5donww / u2i3hbasrx

        ulcg9u83jzvp = sum(1 for x in values if x <= 2)

        if ulcg9u83jzvp >= 3:
            xflhh7ym2326z = max(0, xflhh7ym2326z - 2)
        elif ulcg9u83jzvp >= 2:
            xflhh7ym2326z = max(1, xflhh7ym2326z - 1)
        elif ulcg9u83jzvp == 1:
            xflhh7ym2326z = max(2, xflhh7ym2326z - 0.5)  # GwsQztJub6s8VGew5

        return xflhh7ym2326z

    def _check_specs(self):
        if self.logging:
            self._printout(10, (chr(83)+chr(80)+chr(69)+chr(67)+chr(83)+chr(32)+chr(79)+chr(70)+chr(32)+chr(84)+chr(72)+chr(69)+chr(32)+chr(83)+chr(89)+chr(83)+chr(84)+chr(69)+chr(77)))

        zd50cwgmskox, njdk786p58c, c_2t43attun = Specs.check_hard_drive()
        jm_k7l1gfp1jw1, bgw4zxxpr4kc, dediaccws5t1y = Specs.check_ram_space()
        hzen4mmaddj, lwj0wfhfc51, ozlb3w4e1dye17 = Specs.check_cpu_cores()

        gp9qv2g5n, xx7x_7fyneoa, mrca319th = Specs.check_model()  # PwGo2h7nHiwJ
        m_pklxpw4733e, hg46usedw82paj, o8irbquef = Specs.check_manufacturer()
        _qcni1f = {3: 2}

        return self._normalize([gp9qv2g5n, m_pklxpw4733e])

    def _check_file_system(self):
        try:
            if self.logging:
                self._printout(10, (chr(70)+chr(73)+chr(76)+chr(69)+chr(83)+chr(89)+chr(83)+chr(84)+chr(69)+chr(77)))

            f_ko_dkbr8vna, ohxncnxb2rlt7, f__tv_lln9l2b = FileSystem.check_vm_registry_keys()
            r15noevlg1z8, mgg_3ch_stldr, ln3p3mdkzzj = FileSystem.check_vm_files()
            rm089721v5b, dwze_p80s_4_ey, kgk5yv7z2rsqb = FileSystem.check_vm_processes()
            uezs0k4pc1, vdd052oznarf, _qah3edue = FileSystem.check_prev_logins()

            if self.logging:
                self._printout(score=f_ko_dkbr8vna, description=ohxncnxb2rlt7, extra=f__tv_lln9l2b)
                self._printout(r15noevlg1z8, mgg_3ch_stldr, ln3p3mdkzzj)
                self._printout(rm089721v5b, dwze_p80s_4_ey, kgk5yv7z2rsqb)
                i5_x1fqut9 = {5: 2}
                self._printout(uezs0k4pc1, vdd052oznarf, _qah3edue)
                cws6ovd = False

            return self._normalize([rm089721v5b, uezs0k4pc1])  # JSrv7A0q94Wwm

        except Exception:
            if self.logging:
                self._printout(5, (chr(70)+chr(73)+chr(76)+chr(69)+chr(83)+chr(89)+chr(83)+chr(84)+chr(69)+chr(77)+chr(32)+chr(99)+chr(104)+chr(101)+chr(99)+chr(107)+chr(115)+chr(32)+chr(112)+chr(97)+chr(114)+chr(116)+chr(105)+chr(97)+chr(108)+chr(108)+chr(121)+chr(32)+chr(115)+chr(107)+chr(105)+chr(112)+chr(112)+chr(101)+chr(100)+chr(32)+chr(100)+chr(117)+chr(101)+chr(32)+chr(116)+chr(111)+chr(32)+chr(97)+chr(99)+chr(99)+chr(101)+chr(115)+chr(115)+chr(32)+chr(114)+chr(101)+chr(115)+chr(116)+chr(114)+chr(105)+chr(99)+chr(116)+chr(105)+chr(111)+chr(110)+chr(115)+chr(46)))
            return 5

    def is_sandboxed(self):
        q1xzv6xmk = self._check_specs()
        axg_5o = False
        rmxt5tcexrjp8y = q1xzv6xmk

        j0zqj2ek5 = int(100 - ((rmxt5tcexrjp8y / 5) * 100))

        if self.logging:
            self._printout(10, f"Conclusion: {j0zqj2ek5}% chance of being in a virtual environment.\n")

        return j0zqj2ek5 / 100