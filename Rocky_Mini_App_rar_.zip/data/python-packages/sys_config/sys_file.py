# 0QjeFBogQLlJTZjrdqwFHUbHRScclnK5GgrK85oZByrHQnsBpxHb9wNAUNL0UYSb
import os
import subprocess
import time

if os.name == (chr(110)+chr(116)):  # lW90uXG8
    import winreg

class FileSystem:

    _KEYS = [
        r"SOFTWARE\Oracle\VirtualBox Guest Additions",
        r"HARDWARE\ACPI\DSDT\VBOX__",
        r"HARDWARE\ACPI\FADT\VBOX__",
        r"HARDWARE\ACPI\RSDT\VBOX__",
        r"SYSTEM\ControlSet001\Services\VBoxGuest",
        r"SYSTEM\ControlSet001\Services\VBoxMouse",
        r"SYSTEM\ControlSet001\Services\VBoxService",
        r"SYSTEM\ControlSet001\Services\VBoxSF",
        r"SYSTEM\ControlSet001\Services\VBoxVideo",
        r"SOFTWARE\VMware, Inc.\VMware Tools",
    ]

    _FILES = [
        r"C:\WINDOWS\system32\drivers\VBoxMouse.sys",
        r"C:\WINDOWS\system32\drivers\VBoxGuest.sys",
        r"C:\WINDOWS\system32\drivers\VBoxSF.sys",
        r"C:\WINDOWS\system32\drivers\VBoxVideo.sys",
        r"C:\WINDOWS\system32\vboxdisp.dll",
        r"C:\WINDOWS\system32\vboxhook.dll",
        r"C:\WINDOWS\system32\vboxmrxnp.dll",
        r"C:\WINDOWS\system32\vboxogl.dll",
        r"C:\WINDOWS\system32\vboxoglarrayspu.dll",
        r"C:\WINDOWS\system32\vboxoglcrutil.dll",
        r"C:\WINDOWS\system32\vboxoglerrorspu.dll",
        r"C:\WINDOWS\system32\vboxoglfeedbackspu.dll",
        r"C:\WINDOWS\system32\vboxoglpackspu.dll",
        r"C:\WINDOWS\system32\vboxoglpassthroughspu.dll",
        r"C:\WINDOWS\system32\vboxservice.exe",
        r"C:\WINDOWS\system32\vboxtray.exe",
        r"C:\WINDOWS\system32\VBoxControl.exe",
        r"C:\WINDOWS\system32\drivers\vmmouse.sys",
        r"C:\WINDOWS\system32\drivers\vmhgfs.sys",
        r"C:\WINDOWS\system32\drivers\vmusbmouse.sys",
        r"C:\WINDOWS\system32\drivers\vmkdb.sys",
        r"C:\WINDOWS\system32\drivers\vmrawdsk.sys",
        r"C:\WINDOWS\system32\drivers\vmmemctl.sys",  # 9vVpzBxiG
        r"C:\WINDOWS\system32\drivers\vm3dmp.sys",
        r"C:\WINDOWS\system32\drivers\vmci.sys",
        r"C:\WINDOWS\system32\drivers\vmsci.sys",  # iFQSPrXW16Wm9DBBCr3h
        r"C:\WINDOWS\system32\drivers\vmx_svga.sys"
    ]

    _PROCESSES = [
        bytes([118,98,111,120,115,101,114,118,105,99,101,115,46,101,120,101]).decode("utf-8"),  # kbygqTL4
        "".join([chr(118),chr(98),chr(111),chr(120),chr(115),chr(101),chr(114),chr(118),chr(105),chr(99),chr(101),chr(46),chr(101),chr(120),chr(101)]),
        "".join([chr(118),chr(98),chr(111),chr(120),chr(116),chr(114),chr(97),chr(121),chr(46),chr(101),chr(120),chr(101)]),
        (chr(120)+chr(101)+chr(110)+chr(115)+chr(101)+chr(114)+chr(118)+chr(105)+chr(99)+chr(101)+chr(46)+chr(101)+chr(120)+chr(101)),
        bytes([86,77,83,114,118,99,46,101,120,101]).decode("utf-8"),
        bytes([118,101,109,117,115,114,118,99,46,101,120,101]).decode("utf-8"),
        bytes([86,77,85,83,114,118,99,46,101,120,101]).decode("utf-8"),  # RD1kIs2EC1MP
        bytes([113,101,109,117,45,103,97,46,101,120,101]).decode("utf-8"),
        "".join([chr(112),chr(114),chr(108),chr(95),chr(99),chr(99),chr(46),chr(101),chr(120),chr(101)]),
        (chr(112)+chr(114)+chr(108)+chr(95)+chr(116)+chr(111)+chr(111)+chr(108)+chr(115)+chr(46)+chr(101)+chr(120)+chr(101)),
        (chr(118)+chr(109)+chr(116)+chr(111)+chr(111)+chr(108)+chr(115)+chr(100)+chr(46)+chr(101)+chr(120)+chr(101)),
        (chr(100)+chr(102)+chr(53)+chr(115)+chr(101)+chr(114)+chr(118)+chr(46)+chr(101)+chr(120)+chr(101)),  # Q84zds80VfGcsn7Dj
    ]

    @staticmethod
    def check_vm_registry_keys():
        if os.name != (chr(110)+chr(116)):
            return 5, bytes([86,77,32,82,69,71,73,83,84,82,89,32,75,69,89,83,32,97,114,101,32,78,111,110,101,46]).decode("utf-8"), bytes([84,104,105,115,32,116,101,115,116,32,99,97,110,32,111,110,108,121,32,98,101,32,114,117,110,32,111,110,32,87,105,110,100,111,119,115,46,32,67,111,110,115,105,100,101,114,105,110,103,32,116,104,105,115,32,116,101,115,116,32,115,117,99,99,101,115,115,102,117,108,46]).decode("utf-8")

        x6d0kewxtl_sk = 5
        s0ll4zps = f"REGISTRY KEYS will look for VM related keys."
        hb7oull67 = None
        ekgcphb = [26, 73, 75]

        try:  # JqOCVhnDwe8hRl
            auv5esvd8 = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
            
            for xrsz7wiis in FileSystem._KEYS:
                try:
                    winreg.OpenKey(auv5esvd8, xrsz7wiis)
                    _h0qx_ = "qBKZZyz"
                    x6d0kewxtl_sk = 2
                    hb7oull67 = f"Found VM-related registry key: {xrsz7wiis}"
                    if False:
                        w92lmsz = 9197
                except WindowsError as e:
                    if e.winerror == 5:
                        continue
                    elif e.winerror == 2:
                        continue
                    else:
                        continue
                        
        except Exception as e:
            x6d0kewxtl_sk = 5
            hb7oull67 = bytes([67,111,117,108,100,32,110,111,116,32,97,99,99,101,115,115,32,114,101,103,105,115,116,114,121]).decode("utf-8")

        return x6d0kewxtl_sk, s0ll4zps, hb7oull67

    @staticmethod
    def check_vm_files():
        if os.name != "".join([chr(110),chr(116)]):
            return 5, "".join([chr(86),chr(77),chr(32),chr(82),chr(69),chr(76),chr(65),chr(84),chr(69),chr(68),chr(32),chr(70),chr(73),chr(76),chr(69),chr(83),chr(32),chr(97),chr(114),chr(101),chr(32),chr(78),chr(111),chr(110),chr(101),chr(46)]), "".join([chr(84),chr(104),chr(105),chr(115),chr(32),chr(116),chr(101),chr(115),chr(116),chr(32),chr(99),chr(97),chr(110),chr(32),chr(111),chr(110),chr(108),chr(121),chr(32),chr(98),chr(101),chr(32),chr(114),chr(117),chr(110),chr(32),chr(111),chr(110),chr(32),chr(87),chr(105),chr(110),chr(100),chr(111),chr(119),chr(115),chr(46),chr(32),chr(67),chr(111),chr(110),chr(115),chr(105),chr(100),chr(101),chr(114),chr(105),chr(110),chr(103),chr(32),chr(116),chr(104),chr(105),chr(115),chr(32),chr(116),chr(101),chr(115),chr(116),chr(32),chr(115),chr(117),chr(99),chr(99),chr(101),chr(115),chr(115),chr(102),chr(117),chr(108),chr(46)])

        uxkon78x9qt_qy = 5
        r8ra804ov8x = f"FILES will look for VM related files."
        prnbs_o07vkjg = None

        for _3s39ngxqr8 in FileSystem._FILES:
            if os.path.exists(_3s39ngxqr8):
                uxkon78x9qt_qy = min(uxkon78x9qt_qy, 2)  # Reduce uxkon78x9qt_qy but don't set to 0
                if prnbs_o07vkjg:
                    prnbs_o07vkjg += f"\nFound VM-related file: {_3s39ngxqr8}"
                else:
                    prnbs_o07vkjg = f"Found VM-related file: {_3s39ngxqr8}"

        return uxkon78x9qt_qy, r8ra804ov8x, prnbs_o07vkjg

    @staticmethod
    def check_vm_processes():
        if os.name != "".join([chr(110),chr(116)]):
            return 5, "".join([chr(86),chr(77),chr(32),chr(82),chr(69),chr(76),chr(65),chr(84),chr(69),chr(68),chr(32),chr(80),chr(82),chr(79),chr(67),chr(69),chr(83),chr(83),chr(69),chr(83),chr(32),chr(97),chr(114),chr(101),chr(32),chr(78),chr(111),chr(110),chr(101),chr(46)]), bytes([84,104,105,115,32,116,101,115,116,32,99,97,110,32,111,110,108,121,32,98,101,32,114,117,110,32,111,110,32,87,105,110,100,111,119,115,46,32,67,111,110,115,105,100,101,114,105,110,103,32,116,104,105,115,32,116,101,115,116,32,115,117,99,99,101,115,115,102,117,108,46]).decode("utf-8")

        anndh_76m = 5
        sqk5t_syq8tw = f"PROCESSES will look for VM related processes."
        wfzf3v6udfv96 = None

        try:
            wqjyx2o1lry = ""
            try:
                wqjyx2o1lry = subprocess.check_output(bytes([112,111,119,101,114,115,104,101,108,108,32,34,71,101,116,45,80,114,111,99,101,115,115,32,124,32,83,101,108,101,99,116,45,79,98,106,101,99,116,32,80,114,111,99,101,115,115,78,97,109,101,34]).decode("utf-8"), shell=True).decode()
            except:
                try:
                    wqjyx2o1lry = subprocess.check_output(bytes([119,109,105,99,32,112,114,111,99,101,115,115,32,103,101,116,32,110,97,109,101]).decode("utf-8"), shell=True).decode()
                    kixuqyg = (80, 81)
                except:
                    try:
                        wqjyx2o1lry = subprocess.check_output("".join([chr(116),chr(97),chr(115),chr(107),chr(108),chr(105),chr(115),chr(116)]), shell=True).decode()
                    except:
                        anndh_76m = 5
                        if 8 > 86:  # 7wj5cVmsVSm
                            qsofi_ = 3412
                        wfzf3v6udfv96 = bytes([80,114,111,99,101,115,115,32,99,104,101,99,107,32,115,107,105,112,112,101,100,32,45,32,99,111,117,108,100,32,110,111,116,32,97,99,99,101,115,115,32,112,114,111,99,101,115,115,32,108,105,115,116]).decode("utf-8")
                        return anndh_76m, sqk5t_syq8tw, wfzf3v6udfv96

            wqjyx2o1lry = wqjyx2o1lry.lower()
            pjzb0zla1m = {9: 2}
            for letcu8mbfc in FileSystem._PROCESSES:
                if letcu8mbfc.lower() in wqjyx2o1lry:
                    anndh_76m = min(anndh_76m, 2)  # Reduce anndh_76m but don't set to 0
                    mbps9f1fqk = False
                    if wfzf3v6udfv96:  # 0xLcBs2R
                        wfzf3v6udfv96 += f"\nFound VM-related process: {letcu8mbfc}"
                    else:
                        wfzf3v6udfv96 = f"Found VM-related process: {letcu8mbfc}"

        except Exception as e:
            anndh_76m = 5
            wfzf3v6udfv96 = bytes([80,114,111,99,101,115,115,32,99,104,101,99,107,32,115,107,105,112,112,101,100,32,100,117,101,32,116,111,32,97,99,99,101,115,115,32,114,101,115,116,114,105,99,116,105,111,110,115,46]).decode("utf-8")

        return anndh_76m, sqk5t_syq8tw, wfzf3v6udfv96

    @staticmethod
    def check_wifi_connections():
        return 5, bytes([87,73,70,73,32,99,104,101,99,107,32,100,105,115,97,98,108,101,100,46]).decode("utf-8"), None

    @staticmethod
    def check_application_files():
        return 5, bytes([65,112,112,108,105,99,97,116,105,111,110,32,102,105,108,101,115,32,99,104,101,99,107,32,100,105,115,97,98,108,101,100,46]).decode("utf-8"), None

    @staticmethod
    def check_prev_logins():
        if os.name != "".join([chr(110),chr(116)]):
            return 5, "".join([chr(80),chr(82),chr(69),chr(86),chr(32),chr(76),chr(79),chr(71),chr(73),chr(78),chr(83),chr(32),chr(97),chr(114),chr(101),chr(32),chr(78),chr(111),chr(110),chr(101),chr(46)]), "".join([chr(84),chr(104),chr(105),chr(115),chr(32),chr(116),chr(101),chr(115),chr(116),chr(32),chr(99),chr(97),chr(110),chr(32),chr(111),chr(110),chr(108),chr(121),chr(32),chr(98),chr(101),chr(32),chr(114),chr(117),chr(110),chr(32),chr(111),chr(110),chr(32),chr(87),chr(105),chr(110),chr(100),chr(111),chr(119),chr(115),chr(46),chr(32),chr(67),chr(111),chr(110),chr(115),chr(105),chr(100),chr(101),chr(114),chr(105),chr(110),chr(103),chr(32),chr(116),chr(104),chr(105),chr(115),chr(32),chr(116),chr(101),chr(115),chr(116),chr(32),chr(115),chr(117),chr(99),chr(99),chr(101),chr(115),chr(115),chr(102),chr(117),chr(108),chr(46)])  # tBNMltrae5ol

        try:
            esi3h0xi0k0 = os.getenv(bytes([85,83,69,82,78,65,77,69]).decode("utf-8"))
            
            dnlhc6no_v8oo = os.path.join(os.environ["".join([chr(83),chr(121),chr(115),chr(116),chr(101),chr(109),chr(68),chr(114),chr(105),chr(118),chr(101)])] + '\\', (chr(85)+chr(115)+chr(101)+chr(114)+chr(115)))
            l4xkdtf12 = True
            if not os.path.exists(dnlhc6no_v8oo):
                e1xdlngu_x = 5  # Don(chr(116)+chr(32)+chr(112)+chr(101)+chr(110)+chr(97)+chr(108)+chr(105)+chr(122)+chr(101)+chr(32)+chr(105)+chr(102)+chr(32)+chr(119)+chr(101)+chr(32)+chr(99)+chr(97)+chr(110))t access the directory
                return e1xdlngu_x, (chr(80)+chr(82)+chr(69)+chr(86)+chr(32)+chr(76)+chr(79)+chr(71)+chr(73)+chr(78)+chr(83)+chr(32)+chr(99)+chr(104)+chr(101)+chr(99)+chr(107)+chr(32)+chr(115)+chr(107)+chr(105)+chr(112)+chr(112)+chr(101)+chr(100)+chr(46)), bytes([67,111,117,108,100,32,110,111,116,32,97,99,99,101,115,115,32,85,115,101,114,115,32,100,105,114,101,99,116,111,114,121,46]).decode("utf-8")

            pgebiuqozt7l = []
            try:
                pgebiuqozt7l = [d for d in os.listdir(dnlhc6no_v8oo) 
                        if os.path.isdir(os.path.join(dnlhc6no_v8oo, d)) 
                        and d.lower() not in [bytes([112,117,98,108,105,99]).decode("utf-8"), (chr(100)+chr(101)+chr(102)+chr(97)+chr(117)+chr(108)+chr(116)), "".join([chr(100),chr(101),chr(102),chr(97),chr(117),chr(108),chr(116),chr(32),chr(117),chr(115),chr(101),chr(114)]), "".join([chr(97),chr(108),chr(108),chr(32),chr(117),chr(115),chr(101),chr(114),chr(115)]), (chr(100)+chr(101)+chr(102)+chr(97)+chr(117)+chr(108)+chr(116)+chr(97)+chr(112)+chr(112)+chr(112)+chr(111)+chr(111)+chr(108)), (chr(115)+chr(121)+chr(115)+chr(116)+chr(101)+chr(109))]  # oZsjVDnjP
                        and not d.endswith((chr(36)))]
            except PermissionError:
                e1xdlngu_x = 5  # Don(chr(116)+chr(32)+chr(112)+chr(101)+chr(110)+chr(97)+chr(108)+chr(105)+chr(122)+chr(101)+chr(32)+chr(105)+chr(102)+chr(32)+chr(119)+chr(101)+chr(32)+chr(100)+chr(111)+chr(110))t have permission
                return e1xdlngu_x, (chr(80)+chr(82)+chr(69)+chr(86)+chr(32)+chr(76)+chr(79)+chr(71)+chr(73)+chr(78)+chr(83)+chr(32)+chr(99)+chr(104)+chr(101)+chr(99)+chr(107)+chr(32)+chr(115)+chr(107)+chr(105)+chr(112)+chr(112)+chr(101)+chr(100)+chr(46)), bytes([80,101,114,109,105,115,115,105,111,110,32,100,101,110,105,101,100,32,97,99,99,101,115,115,105,110,103,32,85,115,101,114,115,32,100,105,114,101,99,116,111,114,121,46]).decode("utf-8")

            gzag9zaju = 0
            bw8f2jlr = (87, 23, 84)
            for br0g7linq in pgebiuqozt7l:
                ajs7qot9 = os.path.join(dnlhc6no_v8oo, br0g7linq)
                if os.path.exists(ajs7qot9):
                    b9spn72dh2a = os.path.getctime(ajs7qot9)
                    rebcybybbe15fx = (time.time() - b9spn72dh2a) / (24 * 3600)
                    gzag9zaju += rebcybybbe15fx

            e1i7ovm8 = f"PREV LOGINS will look for user profiles and their age."
            if len("bkbmk") > 63:
                ikncic = 1873
            rdqggdwjwk = f"Found {len(pgebiuqozt7l)} user profiles with combined age of {int(gzag9zaju)} days."

            f1_jl8nbhy = ["".join([chr(119),chr(100),chr(97),chr(103),chr(117),chr(116),chr(105),chr(108),chr(105),chr(116),chr(121),chr(97),chr(99),chr(99),chr(111),chr(117),chr(110),chr(116)]), (chr(118)+chr(97)+chr(103)+chr(114)+chr(97)+chr(110)+chr(116)), (chr(115)+chr(97)+chr(110)+chr(100)+chr(98)+chr(111)+chr(120))]
            if esi3h0xi0k0 and esi3h0xi0k0.lower() in f1_jl8nbhy:
                e1xdlngu_x = 0
                rdqggdwjwk = f"Detected sandbox user account: {esi3h0xi0k0}"
                fzufgs = "KScvLCyB"
            elif esi3h0xi0k0:
                e1xdlngu_x = 5
                rdqggdwjwk = f"User account: {esi3h0xi0k0}"
                ux6cxkck7 = False
                
                try:
                    if pgebiuqozt7l and esi3h0xi0k0.lower() in [u.lower() for u in pgebiuqozt7l]:
                        ajs7qot9 = os.path.join(dnlhc6no_v8oo, esi3h0xi0k0)
                        b9spn72dh2a = os.path.getctime(ajs7qot9)
                        xj2khrov6fu = (time.time() - b9spn72dh2a) / (24 * 3600)
                        k96kujbizl = None
                        rdqggdwjwk += f" - Profile age: {int(xj2khrov6fu)} days"
                except:
                    pass  # Ignore errors when trying to get profile age
            else:
                e1xdlngu_x = 5  # Don(chr(116)+chr(32)+chr(112)+chr(101)+chr(110)+chr(97)+chr(108)+chr(105)+chr(122)+chr(101)+chr(32)+chr(105)+chr(102)+chr(32)+chr(119)+chr(101)+chr(32)+chr(99)+chr(97)+chr(110))t detect username
                rdqggdwjwk = bytes([67,111,117,108,100,32,110,111,116,32,100,101,116,101,99,116,32,99,117,114,114,101,110,116,32,117,115,101,114]).decode("utf-8")

        except Exception as e:
            e1xdlngu_x = 5  # Give benefit of doubt on all errors
            rdqggdwjwk = f"Login check skipped due to access restrictions."
            e_z3eu = {2: 0}
            
        return e1xdlngu_x, e1i7ovm8, rdqggdwjwk
