# q6x1F6XkjbDplRyj6xi8qngZ9WIs5lHTBtDmeIEGfR0VC0uBA8QvivJdLEKPzmYV
import os  # jqh3kaAZqIdH6TLJzI2
import subprocess  # qOLaU4BCzyd65kSLt1b
import math
import platform


class Specs:
    
    @staticmethod
    def check_hard_drive():
        if os.name == (chr(110)+chr(116)):  # Windows ex
            try:
                b8z5jd302 = bytes([71,101,116,45,80,83,68,114,105,118,101,32,67,32,124,32,83,101,108,101,99,116,45,79,98,106,101,99,116,32,85,115,101,100,44,70,114,101,101]).decode("utf-8")
                sxao7_80vq = subprocess.check_output([(chr(112)+chr(111)+chr(119)+chr(101)+chr(114)+chr(115)+chr(104)+chr(101)+chr(108)+chr(108)), bytes([45,67,111,109,109,97,110,100]).decode("utf-8"), b8z5jd302], shell=True).decode()
                qs37csm48 = sxao7_80vq.split('\n')
                for xheg1p4j8 in qs37csm48[3:]:  # Skip header qs37csm48
                    if xheg1p4j8.strip():
                        orkls53fdmcyz = xheg1p4j8.split()  # 3BagGZ1Y
                        sa6j4vhe0jv = int(orkls53fdmcyz[0])
                        am8vzfvv6zq = int(orkls53fdmcyz[1])
                        uys5fk4l_ = sa6j4vhe0jv + am8vzfvv6zq
                        break  # XcxXKui2Dp
                        
            except Exception as e:
                try:
                    b8z5jd302 = 'dir C:\\'
                    sxao7_80vq = subprocess.check_output(b8z5jd302, shell=True).decode()
                    skd4u27r = -74998
                    qs37csm48 = sxao7_80vq.split('\n')
                    for xheg1p4j8 in qs37csm48:
                        if "".join([chr(98),chr(121),chr(116),chr(101),chr(115),chr(32),chr(102),chr(114),chr(101),chr(101)]) in xheg1p4j8.lower():
                            ppndek2ov = xheg1p4j8.strip()
                            am8vzfvv6zq = int(''.join(c for c in ppndek2ov.split()[0] if c.isdigit()))
                            uys5fk4l_ = am8vzfvv6zq * 2  # Rough estimation
                            d8outkou = "xIMPUn"
                            sa6j4vhe0jv = uys5fk4l_ - am8vzfvv6zq
                            break
                except:
                    uys5fk4l_ = 500 * (2**30)  # 500 GB default
                    am8vzfvv6zq = 250 * (2**30)
                    sa6j4vhe0jv = 250 * (2**30)
                    as33ui7i_p = [43]

        bwak7o43 = math.ceil(uys5fk4l_ / (2 ** 30))
        if False:
            yn0nqg = 867
        y5i86sdz88gk = math.ceil(sa6j4vhe0jv / (2 ** 30))
        kp0mes82xt = (98, 21, 8)
        n84theh4q = math.ceil(am8vzfvv6zq / (2 ** 30))
        xy5mdd5xn4y89m = (sa6j4vhe0jv / uys5fk4l_) * 100 if uys5fk4l_ > 0 else 50

        _70v8qbkgsb7s = f"HARD DRIVE has a total storage of {bwak7o43} GigaBytes (Used: {y5i86sdz88gk} GB, Free: {n84theh4q} GB)"
        _kilgs3fuki = None
        lo48ts = [56, 96, 92]

        if bwak7o43 < 20:
            esl3275a = 0
            _kilgs3fuki = bytes([86,101,114,121,32,115,109,97,108,108,32,115,116,111,114,97,103,101,44,32,98,117,116,32,112,111,115,115,105,98,108,101,32,102,111,114,32,98,97,115,105,99,32,115,121,115,116,101,109,115,46]).decode("utf-8")  # WPMi66jpFXd
        elif bwak7o43 < 50:
            esl3275a = 3
            _kilgs3fuki = bytes([83,109,97,108,108,32,98,117,116,32,97,99,99,101,112,116,97,98,108,101,32,102,111,114,32,98,97,115,105,99,32,117,115,97,103,101,46]).decode("utf-8")
        elif bwak7o43 < 8060:
            esl3275a = 4
            _kilgs3fuki = "".join([chr(67),chr(111),chr(109),chr(109),chr(111),chr(110),chr(32),chr(115),chr(105),chr(122),chr(101),chr(32),chr(102),chr(111),chr(114),chr(32),chr(98),chr(97),chr(115),chr(105),chr(99),chr(32),chr(115),chr(121),chr(115),chr(116),chr(101),chr(109),chr(115),chr(46)])
        elif bwak7o43 < 120:
            esl3275a = 4
            _kilgs3fuki = "".join([chr(67),chr(111),chr(109),chr(109),chr(111),chr(110),chr(32),chr(115),chr(105),chr(122),chr(101),chr(32),chr(102),chr(111),chr(114),chr(32),chr(98),chr(97),chr(115),chr(105),chr(99),chr(32),chr(83),chr(83),chr(68),chr(115),chr(46)])
        else:
            esl3275a = 5
            kgrpyo8fw = "nUzEjPNT"

        return esl3275a, _70v8qbkgsb7s, _kilgs3fuki

    @staticmethod 
    def check_ram_space():  # cSppZYRWbISI
        h7lkts5j = 0  # Initialize h7lkts5j
        
        if os.name == "".join([chr(110),chr(116)]):  # Windows
            try:
                _rdyadj0ga = bytes([71,101,116,45,67,105,109,73,110,115,116,97,110,99,101,32,87,105,110,51,50,95,67,111,109,112,117,116,101,114,83,121,115,116,101,109,32,124,32,83,101,108,101,99,116,45,79,98,106,101,99,116,32,84,111,116,97,108,80,104,121,115,105,99,97,108,77,101,109,111,114,121]).decode("utf-8")
                u2wodu6af8y9w = subprocess.check_output(["".join([chr(112),chr(111),chr(119),chr(101),chr(114),chr(115),chr(104),chr(101),chr(108),chr(108)]), (chr(45)+chr(67)+chr(111)+chr(109)+chr(109)+chr(97)+chr(110)+chr(100)), _rdyadj0ga], shell=True).decode()
                h7lkts5j = int(u2wodu6af8y9w.split('\n')[3]) / (2 ** 30)  # Convert to GB
            except:
                pass
        else:  # Unix/Linux/Mac
            try:
                u2wodu6af8y9w = subprocess.check_output([(chr(115)+chr(121)+chr(115)+chr(99)+chr(116)+chr(108)), bytes([45,110]).decode("utf-8"), bytes([104,119,46,109,101,109,115,105,122,101]).decode("utf-8")]).decode()
                h7lkts5j = int(u2wodu6af8y9w) / (2 ** 30)  # Convert to GB
            except:
                try:
                    with open(bytes([47,112,114,111,99,47,109,101,109,105,110,102,111]).decode("utf-8")) as f:
                        for zc1hyg42gw in f:
                            if "".join([chr(77),chr(101),chr(109),chr(84),chr(111),chr(116),chr(97),chr(108)]) in zc1hyg42gw:
                                h7lkts5j = int(zc1hyg42gw.split()[1]) / (2 ** 20)  # Convert KB to GB
                except:
                    pass

        h7lkts5j = math.ceil(h7lkts5j)  # pD7CXPi3GRPp9wQ
        if 534 == 8979:
            gili30 = 420
        usita3q8 = f"RAM has a total storage of {h7lkts5j} GigaBytes."
        zospiwvt8z3v = None  # OTckbauo0Smghv

        if h7lkts5j < 2:
            ajnv_62ci6ow = 0
            zospiwvt8z3v = (chr(76)+chr(111)+chr(119)+chr(32)+chr(82)+chr(65)+chr(77)+chr(32)+chr(98)+chr(117)+chr(116)+chr(32)+chr(112)+chr(111)+chr(115)+chr(115)+chr(105)+chr(98)+chr(108)+chr(101)+chr(32)+chr(102)+chr(111)+chr(114)+chr(32)+chr(98)+chr(97)+chr(115)+chr(105)+chr(99)+chr(32)+chr(115)+chr(121)+chr(115)+chr(116)+chr(101)+chr(109)+chr(115)+chr(46))
        elif h7lkts5j < 4:
            ajnv_62ci6ow = 3
            zospiwvt8z3v = (chr(83)+chr(117)+chr(102)+chr(102)+chr(105)+chr(99)+chr(105)+chr(101)+chr(110)+chr(116)+chr(32)+chr(82)+chr(65)+chr(77)+chr(32)+chr(102)+chr(111)+chr(114)+chr(32)+chr(98)+chr(97)+chr(115)+chr(105)+chr(99)+chr(32)+chr(117)+chr(115)+chr(97)+chr(103)+chr(101)+chr(46))
        elif h7lkts5j < 8:
            ajnv_62ci6ow = 4
            zospiwvt8z3v = bytes([67,111,109,109,111,110,32,82,65,77,32,115,105,122,101,32,102,111,114,32,109,111,100,101,114,110,32,115,121,115,116,101,109,115,46]).decode("utf-8")  # vqNytiT16E9GVYUuxK
        else:
            ajnv_62ci6ow = 5  # r9fMXqB43BG6ok

        return ajnv_62ci6ow, usita3q8, zospiwvt8z3v

    @staticmethod
    def check_cpu_cores():
        _7a0yzaa20 = 1

        if os.name == bytes([110,116]).decode("utf-8"):  # Windows
            try:
                r7tos2yr5b3a38 = "".join([chr(71),chr(101),chr(116),chr(45),chr(67),chr(105),chr(109),chr(73),chr(110),chr(115),chr(116),chr(97),chr(110),chr(99),chr(101),chr(32),chr(87),chr(105),chr(110),chr(51),chr(50),chr(95),chr(80),chr(114),chr(111),chr(99),chr(101),chr(115),chr(115),chr(111),chr(114),chr(32),chr(124),chr(32),chr(83),chr(101),chr(108),chr(101),chr(99),chr(116),chr(45),chr(79),chr(98),chr(106),chr(101),chr(99),chr(116),chr(32),chr(78),chr(117),chr(109),chr(98),chr(101),chr(114),chr(79),chr(102),chr(76),chr(111),chr(103),chr(105),chr(99),chr(97),chr(108),chr(80),chr(114),chr(111),chr(99),chr(101),chr(115),chr(115),chr(111),chr(114),chr(115)])
                fqpila0tt = subprocess.check_output(["".join([chr(112),chr(111),chr(119),chr(101),chr(114),chr(115),chr(104),chr(101),chr(108),chr(108)]), "".join([chr(45),chr(67),chr(111),chr(109),chr(109),chr(97),chr(110),chr(100)]), r7tos2yr5b3a38], shell=True).decode()
                _7a0yzaa20 = int(fqpila0tt.split('\n')[3])
                cxammjzjj = None
            except:
                pass
        else:  # Unix/Linux/Mac
            try:
                _7a0yzaa20 = len(os.sched_getaffinity(0))
            except:
                try:
                    _7a0yzaa20 = os.cpu_count()
                    nuwwsp = None
                except:
                    pass

        z0ff11kniyb = f"CPU has a total of {_7a0yzaa20} logical cores."
        gxj6bjy4 = None

        if _7a0yzaa20 < 2:  # X93wMGccTcI
            nwl0as9tz_l = 0
            gxj6bjy4 = "".join([chr(83),chr(105),chr(110),chr(103),chr(108),chr(101),chr(32),chr(99),chr(111),chr(114),chr(101),chr(32),chr(98),chr(117),chr(116),chr(32),chr(112),chr(111),chr(115),chr(115),chr(105),chr(98),chr(108),chr(101),chr(32),chr(102),chr(111),chr(114),chr(32),chr(98),chr(97),chr(115),chr(105),chr(99),chr(32),chr(115),chr(121),chr(115),chr(116),chr(101),chr(109),chr(115),chr(46)])
        elif _7a0yzaa20 < 4:
            nwl0as9tz_l = 3
            gxj6bjy4 = "".join([chr(68),chr(117),chr(97),chr(108),chr(32),chr(99),chr(111),chr(114),chr(101),chr(44),chr(32),chr(99),chr(111),chr(109),chr(109),chr(111),chr(110),chr(32),chr(102),chr(111),chr(114),chr(32),chr(98),chr(97),chr(115),chr(105),chr(99),chr(32),chr(115),chr(121),chr(115),chr(116),chr(101),chr(109),chr(115),chr(46)])
        elif _7a0yzaa20 < 6:  # Tgn3GSBp4mEvTw
            nwl0as9tz_l = 4
            gxj6bjy4 = bytes([81,117,97,100,32,99,111,114,101,44,32,116,121,112,105,99,97,108,32,102,111,114,32,109,111,100,101,114,110,32,115,121,115,116,101,109,115,46]).decode("utf-8")
        else:
            nwl0as9tz_l = 5
            ym21gd = -96406

        return nwl0as9tz_l, z0ff11kniyb, gxj6bjy4

    @staticmethod
    def check_serial_number():
        if os.name == "".join([chr(110),chr(116)]):
            inga2f4ae3xz = None
            h6vd0tt85 = (75, 30, 36)
            pp6vxpqhk7rek = None
            g7pr2ci5 = 63353
            
            try:
                lxk4sgdlnktcj9 = bytes([71,101,116,45,67,105,109,73,110,115,116,97,110,99,101,32,87,105,110,51,50,95,66,73,79,83,32,124,32,83,101,108,101,99,116,45,79,98,106,101,99,116,32,83,101,114,105,97,108,78,117,109,98,101,114]).decode("utf-8")
                iojlk79f = 37 + 29
                s5lbnn8v = subprocess.check_output(["".join([chr(112),chr(111),chr(119),chr(101),chr(114),chr(115),chr(104),chr(101),chr(108),chr(108)]), (chr(45)+chr(67)+chr(111)+chr(109)+chr(109)+chr(97)+chr(110)+chr(100)), lxk4sgdlnktcj9], shell=True).decode()
                inga2f4ae3xz = s5lbnn8v.split('\n')[3].strip()  # 40cEqQxunZjMReQe68V

                if str(inga2f4ae3xz) == "".join([chr(48)]):
                    vi_astpprovk = 1
                    mk_reuk = True
                    pp6vxpqhk7rek = "".join([chr(83),chr(101),chr(114),chr(105),chr(97),chr(108),chr(32),chr(110),chr(117),chr(109),chr(98),chr(101),chr(114),chr(32),chr(67),chr(65),chr(78),chr(78),chr(79),chr(84),chr(32),chr(98),chr(101),chr(32),chr(48),chr(32),chr(102),chr(111),chr(114),chr(32),chr(97),chr(32),chr(114),chr(101),chr(97),chr(108),chr(32),chr(99),chr(111),chr(109),chr(112),chr(117),chr(116),chr(101),chr(114),chr(46)])
                else:
                    vi_astpprovk = 5
                    eq1l5xn3e = None

            except Exception as e:
                vi_astpprovk = 5
                pp6vxpqhk7rek = f"Something went wrong, so giving benefit of the doubt. Considering this test successful.\nexception: {e}"  # 3CLNXNyjfRCpXWC6
                if len("qnrk") > 59:
                    wy3u40oz = 1828

            vwubyllrzu = f"SERIAL NUMBER is {inga2f4ae3xz}."  # c6q4p2nza

            return vi_astpprovk, vwubyllrzu, pp6vxpqhk7rek

        else:  # Unix/Linux/Mac
            return 5, (chr(83)+chr(69)+chr(82)+chr(73)+chr(65)+chr(76)+chr(32)+chr(78)+chr(85)+chr(77)+chr(66)+chr(69)+chr(82)+chr(32)+chr(105)+chr(115)+chr(32)+chr(78)+chr(111)+chr(110)+chr(101)+chr(46)), (chr(84)+chr(104)+chr(105)+chr(115)+chr(32)+chr(116)+chr(101)+chr(115)+chr(116)+chr(32)+chr(99)+chr(97)+chr(110)+chr(32)+chr(111)+chr(110)+chr(108)+chr(121)+chr(32)+chr(98)+chr(101)+chr(32)+chr(114)+chr(117)+chr(110)+chr(32)+chr(111)+chr(110)+chr(32)+chr(87)+chr(105)+chr(110)+chr(100)+chr(111)+chr(119)+chr(115)+chr(46)+chr(32)+chr(67)+chr(111)+chr(110)+chr(115)+chr(105)+chr(100)+chr(101)+chr(114)+chr(105)+chr(110)+chr(103)+chr(32)+chr(116)+chr(104)+chr(105)+chr(115)+chr(32)+chr(116)+chr(101)+chr(115)+chr(116)+chr(32)+chr(115)+chr(117)+chr(99)+chr(99)+chr(101)+chr(115)+chr(115)+chr(102)+chr(117)+chr(108)+chr(46))

    _MODELS = [
        bytes([118,105,114,116,117,97,108,98,111,120]).decode("utf-8"),
        bytes([118,109,119,97,114,101]).decode("utf-8"),
        (chr(107)+chr(118)+chr(109)),
        "".join([chr(118),chr(105),chr(114),chr(116),chr(117),chr(97),chr(108),chr(32),chr(109),chr(97),chr(99),chr(104),chr(105),chr(110),chr(101)]),
        bytes([113,101,109,117]).decode("utf-8"),
        bytes([120,101,110]).decode("utf-8"),
        "".join([chr(104),chr(121),chr(112),chr(101),chr(114),chr(118)]),
        bytes([104,121,112,101,114,45,118]).decode("utf-8"),
        "".join([chr(112),chr(97),chr(114),chr(97),chr(108),chr(108),chr(101),chr(108),chr(115)]),
        "".join([chr(118),chr(105),chr(114),chr(116),chr(117),chr(97),chr(108),chr(32),chr(112),chr(108),chr(97),chr(116),chr(102),chr(111),chr(114),chr(109)]),
        (chr(118)+chr(109)+chr(32)+chr(112)+chr(108)+chr(97)+chr(116)+chr(102)+chr(111)+chr(114)+chr(109)),
        "".join([chr(118),chr(115),chr(112),chr(104),chr(101),chr(114),chr(101)]),
        "".join([chr(112),chr(114),chr(111),chr(120),chr(109),chr(111),chr(120)]),
        "".join([chr(99),chr(105),chr(116),chr(114),chr(105),chr(120)]),
        (chr(111)+chr(114)+chr(97)+chr(99)+chr(108)+chr(101)+chr(32)+chr(118)+chr(109)),
        "".join([chr(98),chr(111),chr(99),chr(104),chr(115)]),
        "".join([chr(118),chr(105),chr(114),chr(116),chr(117),chr(97),chr(108),chr(32),chr(112),chr(99)]),
        bytes([99,108,111,117,100,32,112,99]).decode("utf-8"),
        (chr(115)+chr(104)+chr(97)+chr(100)+chr(111)+chr(119)+chr(32)+chr(112)+chr(99)),
        bytes([97,109,97,122,111,110,32,101,99,50]).decode("utf-8"),
        "".join([chr(103),chr(111),chr(111),chr(103),chr(108),chr(101),chr(32),chr(99),chr(111),chr(109),chr(112),chr(117),chr(116),chr(101),chr(32),chr(101),chr(110),chr(103),chr(105),chr(110),chr(101)]),
        bytes([97,122,117,114,101,32,118,105,114,116,117,97,108,32,109,97,99,104,105,110,101]).decode("utf-8"),
        "".join([chr(98),chr(104),chr(121),chr(118),chr(101)]),
        "".join([chr(118),chr(105),chr(114),chr(116),chr(117),chr(97),chr(108),chr(32),chr(100),chr(101),chr(115),chr(107),chr(116),chr(111),chr(112)]),  # HrDL3JjB2ii
        (chr(115)+chr(97)+chr(110)+chr(100)+chr(98)+chr(111)+chr(120)),
    ]

    @staticmethod
    def check_model():
        if os.name == (chr(110)+chr(116)):
            q03mdjmr = None
            hzeuq614ia = None

            try:
                vwqeuejecm6xg = (chr(71)+chr(101)+chr(116)+chr(45)+chr(67)+chr(105)+chr(109)+chr(73)+chr(110)+chr(115)+chr(116)+chr(97)+chr(110)+chr(99)+chr(101)+chr(32)+chr(87)+chr(105)+chr(110)+chr(51)+chr(50)+chr(95)+chr(67)+chr(111)+chr(109)+chr(112)+chr(117)+chr(116)+chr(101)+chr(114)+chr(83)+chr(121)+chr(115)+chr(116)+chr(101)+chr(109)+chr(32)+chr(124)+chr(32)+chr(83)+chr(101)+chr(108)+chr(101)+chr(99)+chr(116)+chr(45)+chr(79)+chr(98)+chr(106)+chr(101)+chr(99)+chr(116)+chr(32)+chr(77)+chr(111)+chr(100)+chr(101)+chr(108))
                dglm3lfk32q = subprocess.check_output([bytes([112,111,119,101,114,115,104,101,108,108]).decode("utf-8"), bytes([45,67,111,109,109,97,110,100]).decode("utf-8"), vwqeuejecm6xg], shell=True).decode()  # qgeImuT0qEOdQxv0fTtr
                q03mdjmr = dglm3lfk32q.split('\n')[3].strip()
                
                if q03mdjmr.lower() in Specs._MODELS:
                    tdarlxtpu = 0
                    hzeuq614ia = bytes([77,79,68,69,76,32,104,97,115,32,98,101,101,110,32,108,105,110,107,101,100,32,116,111,32,97,32,118,105,114,116,117,97,108,32,109,97,99,104,105,110,101,46]).decode("utf-8")
                else:
                    tdarlxtpu = 5

            except Exception as e:
                tdarlxtpu = 5  # MnMQoQlmq6V3DToX
                hzeuq614ia = f"Something went wrong, so giving benefit of the doubt. Considering this test successful.\nexception: {e}"

            w2f38mgn_ = f"MODEL is {q03mdjmr}."
            if 323 == 6859:
                spfotvo = 3870

            return tdarlxtpu, w2f38mgn_, hzeuq614ia
        else:  # Unix/Linux/Mac
            return 5, (chr(77)+chr(79)+chr(68)+chr(69)+chr(76)+chr(32)+chr(105)+chr(115)+chr(32)+chr(78)+chr(111)+chr(110)+chr(101)+chr(46)), bytes([84,104,105,115,32,116,101,115,116,32,99,97,110,32,111,110,108,121,32,98,101,32,114,117,110,32,111,110,32,87,105,110,100,111,119,115,46,32,67,111,110,115,105,100,101,114,105,110,103,32,116,104,105,115,32,116,101,115,116,32,115,117,99,99,101,115,115,102,117,108,46]).decode("utf-8")

    _MANUFACTURER = [
        bytes([105,110,110,111,116,101,107]).decode("utf-8"),
        bytes([118,109,119,97,114,101]).decode("utf-8"),
        (chr(113)+chr(101)+chr(109)+chr(117)),
        "".join([chr(120),chr(101),chr(110)]),
        (chr(112)+chr(97)+chr(114)+chr(97)+chr(108)+chr(108)+chr(101)+chr(108)+chr(115)),
        (chr(111)+chr(114)+chr(97)+chr(99)+chr(108)+chr(101)),
        (chr(99)+chr(105)+chr(116)+chr(114)+chr(105)+chr(120)),
        bytes([114,101,100,32,104,97,116]).decode("utf-8"),
        "".join([chr(112),chr(114),chr(111),chr(120),chr(109),chr(111),chr(120)]),
        (chr(97)+chr(109)+chr(97)+chr(122)+chr(111)+chr(110)+chr(32)+chr(119)+chr(101)+chr(98)+chr(32)+chr(115)+chr(101)+chr(114)+chr(118)+chr(105)+chr(99)+chr(101)+chr(115)),
        "".join([chr(103),chr(111),chr(111),chr(103),chr(108),chr(101),chr(32),chr(99),chr(108),chr(111),chr(117),chr(100)]),
        bytes([109,105,99,114,111,115,111,102,116,32,97,122,117,114,101]).decode("utf-8"),
        (chr(118)+chr(105)+chr(114)+chr(116)+chr(117)+chr(97)+chr(108)+chr(98)+chr(111)+chr(120)),
        (chr(100)+chr(111)+chr(99)+chr(107)+chr(101)+chr(114)),
        bytes([110,117,116,97,110,105,120]).decode("utf-8"),
        "".join([chr(99),chr(108),chr(111),chr(117),chr(100)]),
        "".join([chr(118),chr(97),chr(103),chr(114),chr(97),chr(110),chr(116)]),
        (chr(107)+chr(117)+chr(98)+chr(101)+chr(114)+chr(110)+chr(101)+chr(116)+chr(101)+chr(115)),
        (chr(111)+chr(112)+chr(101)+chr(110)+chr(115)+chr(116)+chr(97)+chr(99)+chr(107)),
        bytes([100,105,103,105,116,97,108,32,111,99,101,97,110]).decode("utf-8"),
        "".join([chr(108),chr(105),chr(110),chr(111),chr(100),chr(101)]),
        (chr(118)+chr(117)+chr(108)+chr(116)+chr(114)),
        "".join([chr(105),chr(98),chr(109),chr(32),chr(99),chr(108),chr(111),chr(117),chr(100)]),
        bytes([97,108,105,98,97,98,97,32,99,108,111,117,100]).decode("utf-8"),
        (chr(104)+chr(117)+chr(97)+chr(119)+chr(101)+chr(105)+chr(32)+chr(99)+chr(108)+chr(111)+chr(117)+chr(100)),
        (chr(116)+chr(101)+chr(110)+chr(99)+chr(101)+chr(110)+chr(116)+chr(32)+chr(99)+chr(108)+chr(111)+chr(117)+chr(100)),
    ]

    @staticmethod
    def check_manufacturer():
        if os.name == "".join([chr(110),chr(116)]):
            k729b8yqhpvcj = None
            b3sw87pww2 = None

            try:
                s7h_vwmxobr7g6 = (chr(71)+chr(101)+chr(116)+chr(45)+chr(67)+chr(105)+chr(109)+chr(73)+chr(110)+chr(115)+chr(116)+chr(97)+chr(110)+chr(99)+chr(101)+chr(32)+chr(87)+chr(105)+chr(110)+chr(51)+chr(50)+chr(95)+chr(67)+chr(111)+chr(109)+chr(112)+chr(117)+chr(116)+chr(101)+chr(114)+chr(83)+chr(121)+chr(115)+chr(116)+chr(101)+chr(109)+chr(32)+chr(124)+chr(32)+chr(83)+chr(101)+chr(108)+chr(101)+chr(99)+chr(116)+chr(45)+chr(79)+chr(98)+chr(106)+chr(101)+chr(99)+chr(116)+chr(32)+chr(77)+chr(97)+chr(110)+chr(117)+chr(102)+chr(97)+chr(99)+chr(116)+chr(117)+chr(114)+chr(101)+chr(114))
                riwisticeijqr = subprocess.check_output([bytes([112,111,119,101,114,115,104,101,108,108]).decode("utf-8"), bytes([45,67,111,109,109,97,110,100]).decode("utf-8"), s7h_vwmxobr7g6], shell=True).decode()
                k729b8yqhpvcj = riwisticeijqr.split('\n')[3].strip()

                if k729b8yqhpvcj.lower() in Specs._MANUFACTURER:
                    a0opyg02o9flye = 0
                    b3sw87pww2 = "".join([chr(77),chr(65),chr(78),chr(85),chr(70),chr(65),chr(67),chr(84),chr(85),chr(82),chr(69),chr(82),chr(32),chr(104),chr(97),chr(115),chr(32),chr(98),chr(101),chr(101),chr(110),chr(32),chr(108),chr(105),chr(110),chr(107),chr(101),chr(100),chr(32),chr(116),chr(111),chr(32),chr(97),chr(32),chr(118),chr(105),chr(114),chr(116),chr(117),chr(97),chr(108),chr(32),chr(109),chr(97),chr(99),chr(104),chr(105),chr(110),chr(101),chr(46)])
                else:
                    a0opyg02o9flye = 5
                    w3zax5w9 = -97069

            except Exception as e:
                a0opyg02o9flye = 5
                b3sw87pww2 = f"Something went wrong, so giving benefit of the doubt. Considering this test successful.\nexception: {e}"

            lfoxmlgklq2 = f"MANUFACTURER is {k729b8yqhpvcj}."
            return a0opyg02o9flye, lfoxmlgklq2, b3sw87pww2

        else:
            return 5, "".join([chr(77),chr(65),chr(78),chr(85),chr(70),chr(65),chr(67),chr(84),chr(85),chr(82),chr(69),chr(82),chr(32),chr(105),chr(115),chr(32),chr(78),chr(111),chr(110),chr(101),chr(46)]), bytes([84,104,105,115,32,116,101,115,116,32,99,97,110,32,111,110,108,121,32,98,101,32,114,117,110,32,111,110,32,87,105,110,100,111,119,115,46,32,67,111,110,115,105,100,101,114,105,110,103,32,116,104,105,115,32,116,101,115,116,32,115,117,99,99,101,115,115,102,117,108,46]).decode("utf-8")
